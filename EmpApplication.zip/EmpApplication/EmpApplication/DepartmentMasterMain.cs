﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
   public class DepartmentMasterMain
    {
        static void Main()
        {
            DepartmentMasterDAL deptdal = new DepartmentMasterDAL();
            DepartmentMaster dept = new DepartmentMaster()
            {
                EmpDepartment = "MARKETING",
                EmpDesignation = "MANAGER"
            };
            if (deptdal.SaveDepartment(dept))
            {
                Console.WriteLine("Department Information Saved");
            }
            else
            {
                Console.WriteLine("Error ocurred");
            }


            Console.ReadLine();
        }
    }
}
