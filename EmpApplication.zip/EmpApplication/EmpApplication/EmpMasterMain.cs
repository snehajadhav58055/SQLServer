﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    public class EmpMasterMain
    {
        static void Main(string[] args)
        {
            EmpMasterDAL empdal = new EmpMasterDAL();
            UserInfoDAL user = new UserInfoDAL();
           
            bool flag = user.IsValidUser("Admin", "admin123");
            if (flag)
            {
                Console.WriteLine("Enter 1.Save Employee \n 2.Delete Employee \n 3.Update Employee \n 4.View Employee");
                int ResNo = Convert.ToInt32(Console.ReadLine());
                switch (ResNo)
                {
                    case 1:
                        #region Save Employee
                        EmpMaster emp = new EmpMaster()
                        {
                            EmpCode = 1,
                            EmpName = "Scott",
                            EmpDob = Convert.ToDateTime("1980-02-01"),
                            EmpGender = "Male",
                            EmpDepartment = "SALES",
                            EmpDesignation = "Manager"
                        };
                        if (empdal.SaveEmployee(emp))
                        {
                            Console.WriteLine("Employee Information Saved");
                        }
                        else
                        {
                            Console.WriteLine("Error ocurred");
                        }

                        #endregion
                        break;

                    case 2:
                        #region Delete Employee
                        int EmpCode = 1;
                        if (empdal.DeleteEmployee(EmpCode))
                        {
                            Console.WriteLine($"Employee {EmpCode} is Deleted");
                        }
                        else
                        {
                            Console.WriteLine("Employee is not deleted");
                        }
                        #endregion
                        break;

                    case 3:
                        #region Update Employee
                        EmpMaster emp1 = new EmpMaster()
                        {
                            EmpCode = 1,
                            EmpName = "Sagar"

                        };

                        if (empdal.UpdateEmployee(emp1))
                        {
                            Console.WriteLine($"Employee Information updated");
                        }
                        else
                        {
                            Console.WriteLine("Employee is not updated");
                        }
                        #endregion
                        break;

                    case 4:
                        #region View Employee
                        EmpMaster viewemp = empdal.ViewEmployee(1);
                        if (viewemp != null)
                        {
                            Console.WriteLine($"{viewemp.EmpCode}\t{viewemp.EmpName}\t" +
                                $"{viewemp.EmpDob.ToString("dd-MMM-yyyy")}\t{viewemp.EmpGender}\t {viewemp.EmpDepartment}\t{viewemp.EmpDesignation}");
                        }
                        else
                        {
                            Console.WriteLine("Employee not exist");
                        }
                        #endregion
                        break;
                    default:
                        Console.WriteLine("Enter valid choice..");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Incorrect username and Password");
            }
            Console.ReadLine();

        }
    }
}
