﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.DAL;
using EmpApplication.EntityModel;

namespace EmpApplication
{
    public class Program
    {
        static void Main(string[] args)
        {
            EmpMasterDAL empdal = new EmpMasterDAL();
            EmpMaster emp = new EmpMaster()
            {
                EmpCode = 1,
                EmpName = "Scott",
                EmpDob = Convert.ToDateTime("1980-02-01"),
                EmpGender = "Male",
                EmpDepartment = "SALES",
                EmpDesignation = "Manager"
            };
            if (empdal.SaveEmployee(emp))
            {
                Console.WriteLine("Employee Information Saved");
            }
            else
            {
                Console.WriteLine("Error ocurred");
            }


        }
    }
}
