﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using EmpApplication.EntityModel;
using System.Data;
namespace EmpApplication.DAL
{
    public class EmpMasterDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        public bool SaveEmployee(EmpMaster emp)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "insert into EmpMaster values(" + emp.EmpCode + ",'" + emp.EmpName + "','" +
                   emp.EmpDob + "','" + emp.EmpGender +"','" + emp.EmpDepartment+"','"+emp.EmpDesignation+"' )";
                if(sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool DeleteEmployee(int EmpCode)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "delete from EmpMaster where EmpCode = " + EmpCode + "";
                if(sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();

                return true;
            }
            catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public bool UpdateEmployee(EmpMaster emp)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "update EmpMaster set EmpName = '" + emp.EmpName + "' where EmpCode = " + emp.EmpCode + "";
                if(sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }

        public EmpMaster ViewEmployee(int EmpCode)
        {
            EmpMaster emp = new EmpMaster();
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select * from EmpMaster where EmpCode = " + EmpCode + "";
                if(sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    emp.EmpCode = Convert.ToInt32( dr["EmpCode"]);
                    emp.EmpName = dr["EmpName"].ToString();
                    emp.EmpDob = Convert.ToDateTime(dr["EmpDob"]);
                    emp.EmpGender = dr["EmpGender"].ToString();
                    emp.EmpDepartment = dr["EmpDepartment"].ToString();
                    emp.EmpDesignation = dr["EmpDesignation"].ToString();
                }
                dr.Close();

                return emp;
            }catch(SqlException ex)
            {
                return emp;
            }

            finally
            {
                sqlcon.Close();
            }
        }
    }
}
