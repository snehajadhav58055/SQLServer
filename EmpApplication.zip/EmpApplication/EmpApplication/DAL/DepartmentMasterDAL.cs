﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.EntityModel;
using System.Data;
using System.Data.SqlClient;

namespace EmpApplication.DAL
{
    class DepartmentMasterDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        public bool SaveDepartment(DepartmentMaster dept)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "insert into DepartmentMaster values ('" + dept.EmpDepartment + "','" + dept.EmpDesignation + "')";
                if(sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
