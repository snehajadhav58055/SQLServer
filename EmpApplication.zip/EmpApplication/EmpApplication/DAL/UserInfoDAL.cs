﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpApplication.EntityModel;
using System.Data.SqlClient;
using System.Data;

namespace EmpApplication.DAL
{
    class UserInfoDAL
    {
        SqlConnection sqlcon = new SqlConnection(EmpApplication.Properties.Settings1.Default.ConStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        public bool IsValidUser(string UserName,string Password)
        {
            try
            {
                cmd.Connection = sqlcon;
                cmd.CommandText = "select * from UserInfo where UserName = '" + UserName.Trim() + "' and Password = '" + Password + "' ";
                if(sqlcon.State == ConnectionState.Closed)
                {
                    sqlcon.Open();
                }
                dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }
               
            }
            catch(SqlException ex)
            {
                return false;
            }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
